import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'home',
  standalone: true,
  templateUrl: './home.component.html',
})
export class HomeComponent {
  public title: string = 'Bienvenido a Red Social'; // Título del componente

  constructor(private _router: Router) {}

  navigateToProfile() {
    this._router.navigate(['/profile']);
  }

  navigateToTimeline() {
    this._router.navigate(['/timeline']);
  }

  navigateToPeople() {
    this._router.navigate(['/people']);
  }
}
