// app.routes.d.ts

declare module './app/app.routes' {
  import { Routes } from '@angular/router';

  const routes: Routes;
  export default routes;
}
