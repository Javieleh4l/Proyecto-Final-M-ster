export class Follow{
    constructor(
        public_id: string,
        public_user: string,
        public_followed: string
    ){}
}