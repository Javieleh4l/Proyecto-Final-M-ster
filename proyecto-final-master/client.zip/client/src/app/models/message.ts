export class Message{
    constructor(
        public_id: string,
        public_text: string,
        public_viewed: string,
        public_created_at: string,
        public_emitter: string,
        public_receiver: string
    ){}
}