export class Publication{
    constructor(
        public_id: string,
        public_text: string,
        public_file: string,
        public_created_at: string,
        public_user: string
    ){}
}