// src/app/services/global.ts
export var GLOBAL = {
    url: 'http://localhost:3800/api/'
};
